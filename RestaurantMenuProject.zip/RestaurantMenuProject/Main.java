package menu;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     
      System.out.println("------------------");
      ChineseMenu chineseMenu = new ChineseMenu();
      chineseMenu.addItem("Chopsuey", 12.88);
      chineseMenu.addItem("Kung Pao Chicken", 11.88);
      chineseMenu.addItem("Noodle soup", 10.89);
      
      MexicanMenu mexicanMenu = new MexicanMenu();
      mexicanMenu.addItem("Burrito bowl", 7.99);
      mexicanMenu.addItem("Taco", 6.99);
      mexicanMenu.addItem("Guacamole",5.99);
      RestaurantMenu restaurantMenu = new RestaurantMenu("DeliciousEats","Multi cuisine","Overall good");
      System.out.println("-------------------------");
      restaurantMenu.displayRestaurantName();
      restaurantMenu.displayReviews();
     // restaurantMenu.displayReviews();
      System.out.println("-------------------------");
      chineseMenu.displayReviews();
      System.out.println("-------------------------");
      mexicanMenu.displayReviews();
      
       
	}

}
