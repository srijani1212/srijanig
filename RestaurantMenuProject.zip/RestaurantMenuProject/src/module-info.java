/**
 * 
 */
/**
 * 
 */
module RestaurantMenuProject {
}