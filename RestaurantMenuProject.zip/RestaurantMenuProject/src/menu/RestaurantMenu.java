package menu;

public class RestaurantMenu extends Menu {
private String restaurantName;
private String cuisineType;
private String addReview;
public RestaurantMenu(String restaurantName,String cuisineType,String addReview)
{
	this.restaurantName = restaurantName;
	this.cuisineType = cuisineType;
	this.addReview = addReview;
}
void displayRestaurantName()
{
	System.out.println("Restaurant Name :" +restaurantName);
}
void displayReviews()
{
	//System.out.println("Restaurant Name :" +restaurantName);
	System.out.println("Cuisine Type :" +cuisineType);
	System.out.println("Add Review :" +addReview);
}
}
