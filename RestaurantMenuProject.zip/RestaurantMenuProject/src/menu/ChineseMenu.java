package menu;

public class ChineseMenu extends RestaurantMenu {
public ChineseMenu()
{
super("DeliciousEats","Chinese","Very good");

}
}