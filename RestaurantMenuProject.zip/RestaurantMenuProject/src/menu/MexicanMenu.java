package menu;

public class MexicanMenu extends RestaurantMenu{
public MexicanMenu()
{
 super("DeliciousEats","Mexican","good");
}
}
