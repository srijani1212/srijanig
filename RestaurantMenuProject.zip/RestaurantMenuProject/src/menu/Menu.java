package menu;

public class Menu {
private String[] items;
private double[] prices;
private int itemCount;

public Menu()
{
	items = new String[10];
	prices = new double[10];
	itemCount = 0;
}
void addItem(String itemName, double price)
{
	if(itemCount<items.length)
	{
		items[itemCount] = itemName;
		prices[itemCount] = price;
		itemCount++;
		System.out.println(itemName + "-$" + price + " has been added to menu");
	}
	else
	{
		System.out.println("Menu is full");
		
	}
}
public void displayMenu()
{
	System.out.println("Menu");
	for(int i=0;i<itemCount;i++)
	{
		System.out.println(items[i]+"-$"+prices[i]);
	}
	System.out.println("-----------");
}
}
